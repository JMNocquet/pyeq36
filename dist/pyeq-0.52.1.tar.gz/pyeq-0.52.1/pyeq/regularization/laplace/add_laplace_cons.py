def add_laplace_cons( model ):
    """
    Adds Discrete Laplace regularization to the normal system
    """

    DEBUG=True
    model.verbose=True

    # import
    import pyeq.regularization.laplace
    import pyeq.message.message as MESSAGE
    import pyeq.message.verbose_message as VERBOSE
    import pyeq.message.warning as WARNING
    import pyeq.message.error as ERROR

    # get spatial DLO
    MESSAGE("Making Discrete Laplace Operator for the triangular mesh")
    dlos = pyeq.regularization.laplace.make_dlo_trimesh( model.geometry, stencil=4, verbose=model.verbose)

    # normalize
    print(dlos)
    MESSAGE("Normalizing Discrete Laplace Operator for the triangular mesh")
    ndlos = pyeq.regularization.laplace.normalize_dlo_trimesh( dlos , float(model.lambda_spatial_smoothing) )

    # get temporal DLO
    MESSAGE("Making Discrete Laplace Operator for temporal smoothing")
    dlot = pyeq.regularization.laplace.make_dlo_temporal( model.nfaults, model.nstep)

    # normalize
    MESSAGE("Normalizing Discrete Laplace Operator for temporal smoothing")
    ndlot = pyeq.regularization.laplace.normalize_dlo_temporal( dlot , float(model.lambda_temporal_smoothing) )

    # apply Laplace regularization
    MESSAGE("Merging spatial and temporal constraints and adding it to the normal system")
    model.N += pyeq.regularization.laplace.make_normal_dlo_space_time( ndlos, ndlot)

    # not sure whether this is OK
    model.lambda_spatial_smoothing = float(model.lambda_spatial_smoothing)
    model.lambda_temporal_smoothing = float(model.lambda_temporal_smoothing)
    model.lambda_damping = float(model.lambda_damping)

    return model