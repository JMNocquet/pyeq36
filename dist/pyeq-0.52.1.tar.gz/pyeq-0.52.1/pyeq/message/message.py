def message( str , level=0 ):
    """
    print message
    """

    if level > 0:
        banner = '###############################################################################'
        str = str.upper()
        print(banner)
        print("[PYEQ] %s" % (str))
        print(banner)

    else:
        print("[PYEQ] %s" % (str))

