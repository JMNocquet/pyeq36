def make_normal_dlo_space_time( model , dlos, dlot):
    """
    Make the normal system for Discrete Laplace Operator (DLO) for space and time from space and time DLO
    """

    # import
    import numpy as np
    import scipy.sparse
    from time import time

    # import
    import scipy.sparse
    import pyeq.regularization.laplace
    import pyeq.message.message as MESSAGE
    import pyeq.message.verbose_message as VERBOSE
    import pyeq.message.debug_message as DEBUG
    import pyeq.message.warning as WARNING
    import pyeq.message.error as ERROR

    # get nfault and nstep

    nfault = dlos.shape[0]
    nstep = int( dlot.shape[0] / nfault )

    # duplicate dlos nstep times into dlot

    # dlos lil to dia
    dlos_dia_single = dlos.todia()

    # fills the block diagonal dlos_dia_single into dlot
    dlos_dia = scipy.sparse.block_diag([dlos_dia_single for _ in range(nstep)]).todia()

    diag = -dlos_dia.sum(axis=1).A1 -dlot.sum(axis=1).A1
    dlot.setdiag(diag)

    dlot += dlos_dia

    # normal system
    import pyeq.message.message as MESSAGE
    import pyeq.message.warning as WARNING
    import pyeq.message.error as ERROR
    MESSAGE("Building normal system for regularization from Discrete Laplace Operators. This can take a few minutes.")
    # change 09/04/2021 - improves memory use
    # dlot is a sparse matrix and dlot.T dlot still remains in sparse format
    # previous solution was model.N += dlot.transpose().dot(dlot)
    # which converts dlot.T dlot to a dense matrix before adding it.
    # This resulted in doubling memory use
    # The new solution directly uses the indices of non-zero element from the sparse matrix
    # This also appears to be faster
    # I checked that results are model.N remains the same

    Ndlot = dlot.transpose().dot(dlot)
    VERBOSE("memory usage after building the sparse normal matrix: %.2lf Gb" % pyeq.log.get_process_memory_usage())
    rows = sum((m * [k] for k, m in enumerate(np.diff(Ndlot.indptr))), [])
    model.N[rows,Ndlot.indices] += Ndlot.data

    #return N_dlots
    return model