def add_spatial_constraint_average_operator(model):
    """
    Add spatial regularization constraints.
    Regularization are imposed through an operator indicating that any slip rate on a sub-fault at a given\
    model time step is equal to the weighted average of slip at surrounding sub-faults.

    """



    # NOTES

    ###############################################################################
    # IMPORT
    ###############################################################################

    import numpy as np
    import scipy.linalg
    import pyeq.lib.regularization
    import pyeq.lib.log

    ###########################################################################
    # INITIALIZE SOME PARAMETERS
    ###########################################################################

    # size of the block matrix associated with slip parameters
    ncm = model.nfaults * model.nstep

    ###############################################################################
    # GET THE INTER SUBFAULT DISTANCE AS A SINGLE SCALAR
    ###############################################################################

    if model.verbose:
        print("-- getting inter subfault distance")

    dc = pyeq.lib.regularization.get_inter_subfault_distance( model.dm, dmin=2, dmax=100, step=0.25, n_contiguous=3)

    if model.verbose:
        print("-- subfault distance (km): %.2lf" % (dc) )

    ###############################################################################
    # MAKE THE SPATIAL AVERAGE OPERATOR FOR A SINGLE TIME STEP
    ###############################################################################

    if model.verbose:
        print("-- making the spatial average operator for a single time step")

    SAO = pyeq.lib.regularization.make_spatial_average_operator( model.dm, dc)

    ###############################################################################
    # BUILD THE FULL SET OF CONSTRAINTS
    ###############################################################################

    SPATIAL_CONSTRAINT = np.dot( SAO.T , SAO ) * (model.lambda_spatial_smoothing / model.nfaults)

    print("-- Filling diagonal blocks")
    model.N[:ncm, :ncm] = model.N[:ncm, :ncm] + scipy.linalg.block_diag(*([ SPATIAL_CONSTRAINT ] * model.nstep))

    ###############################################################################
    # HANDLE ORIGIN TIME CONSTANTS
    ###############################################################################
    if model.offset > 0:
        np.fill_diagonal(model.N[-model.nconstant:, -model.nconstant:],
                         np.diagonal(model.N[-model.nconstant:, -model.nconstant:]) + 1. / model.offset ** 2)

    return model
