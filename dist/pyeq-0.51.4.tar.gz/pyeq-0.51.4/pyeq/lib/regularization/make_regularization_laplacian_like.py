def make_regularization_laplacian_like( model ):
    """
    Makes a laplacian like regularization, consisting in:
    - adding constraints in the normal system through a discrete spatial average operator
    - adding constraints in the normal system through a time discrete differential operator
    - adding damping constraints in the normal system through the identity equation
    """

    ###########################################################################
    # IMPORT
    ###########################################################################

    import pyeq.lib.regularization

    ###########################################################################
    # CHECK ATTRIBUTES EXIST
    ###########################################################################

    check_attr = ['lambda_spatial_smoothing','lambda_temporal_smoothing','lambda_damping']

    for attr in check_attr:

        if not hasattr( model ,  attr ):
            print("ERROR: model has no option %s. Exiting." % (attr) )
            import sys
            exit()


    ###########################################################################
    # CONVERT TYPES AND RENORMALIZE BY NFAULTS
    ###########################################################################

    model.lambda_spatial_smoothing = float( model.lambda_spatial_smoothing )
    model.lambda_temporal_smoothing = float( model.lambda_temporal_smoothing )
    model.lambda_damping = float( model.lambda_damping )

    ###########################################################################
    # PRINT INFO
    ###########################################################################

    print("-- parameters for laplacian like regularization")
    print("   spatial smoothing : %.2lf " % model.lambda_spatial_smoothing )
    print("   temporal smoothing: %.2lf " % model.lambda_temporal_smoothing )
    print("   damping           : %.2lf " % model.lambda_damping )

    ###########################################################################
    # SPATIAL
    ###########################################################################

    print("-- Spatial constraints")
    if model.lambda_spatial_smoothing > 0:
        model = pyeq.lib.regularization.add_spatial_constraint_average_operator( model )

    ###########################################################################
    # TEMPORAL
    ###########################################################################

    print("-- Temporal constraints")
    if model.lambda_temporal_smoothing > 0:
        model = pyeq.lib.regularization.add_temporal_constraint_average_operator( model )

    ###########################################################################
    # DAMPING
    ###########################################################################

    print("-- Damping constraints")
    if model.lambda_damping > 0:
        model = pyeq.lib.regularization.add_damping_constraint( model )

    return model