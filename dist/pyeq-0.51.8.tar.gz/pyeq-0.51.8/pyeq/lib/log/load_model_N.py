def load_model_N( model ):
    """
    load model as pck and npy file for the normal system
    """

    # import
    from datetime import datetime
    import pickle
    import numpy as np
    import os

    # load model pck file

    # loads the pck
    print("-- Loading %s (%.2f Gb) " % ( model.pck, os.path.getsize( model.pck ) /1024 / 1024 / 1024 ) )
    with open( model.pck, "rb") as f:
        model = pickle.load( f )
    f.close()
    print("-- model object loaded.")


    # load npy files
    print("-- Loading Observation Normal Matrix and Vector :\n- %s\n- %s " % ( model.N_fn, model.Nd_fn ))
    try:
        model.N = np.load(model.N_fn)
        model.Nd = np.load(model.Nd_fn)
    except:
        print("ERROR saving npy file")


    return model
