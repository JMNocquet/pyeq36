class pyeq_model:     
    def __init__ (self):
        pass

    @classmethod
    ###################################################################
    def load(cls, file_name=None, verbose=False):
    ###################################################################
        """
        load an existing pyeq model.

        param file_name: model file as pickle
        param verbose: verbose mode

        """

        import pickle
        import os
        from colors import red
        import sys

        try:
            print("-- Loading %s (%.2f Gb) " % ( file_name , os.path.getsize( file_name ) /1024 / 1024 / 1024 ) )
            with open( file_name, "rb") as f:
                model = pickle.load( f )
            f.close()
            print("-- model object loaded.")
        except:
            print( red("[PYEQ ERROR] Could not load: %s " % ( file_name ) ))
            sys.exit()

        return model

    ###################################################################
    def print_info(cls):
    ###################################################################
        """
        print info on a model
        """

        import numpy as np

        for attr in sorted( cls.__dict__):
            if isinstance( cls.__dict__[attr], float ):
                print("-- %s : %.2E" % (attr,cls.__dict__[attr]))
            if isinstance( cls.__dict__[attr], str ):
                print("-- %s : %s" % (attr,cls.__dict__[attr]))
            if isinstance( cls.__dict__[attr], np.ndarray ):
                print('-- %s : '  % attr,  cls.__dict__[attr].shape)

    ###################################################################
    def write_pickle(cls, file_name=None):
    ###################################################################
        """
        write a model object as pickle
        """

        import pickle
        import os

        print("-- writing %s" % file_name  )

        ofile = open( file_name , 'wb')
        pickle.dump( cls , ofile , pickle.DEFAULT_PROTOCOL)
        ofile.close()

        print("-- %s (%.2f Gb) written" % (file_name, os.path.getsize(file_name) / 1024 / 1024 / 1024))

