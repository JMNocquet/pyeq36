def plot_time_series( model ):
    """
    Plot time series
    """
    from progress.bar import Bar
    from time import time

    import multiprocessing
    from joblib import Parallel, delayed
    from tqdm import tqdm
    
    num_cores = multiprocessing.cpu_count()
    inputs = tqdm( model.Ogts.lcode() )
    
    def plot_ts_pyeq( site , model ):

        _dev_nul = model.Ogts.__dict__[ site ].plot( \
                                          superimposed=[ model.Mgts.__dict__[ site ] ], \
                                          date_unit='cal',\
                                          save_dir_plots = model.odir + '/plots/ts', \
                                          save = True, \
                                          show = False, \
                                          center = False, \
                                          verbose=  model.verbose,\
                                           )
        
    processed_list = Parallel(n_jobs=num_cores)(delayed( plot_ts_pyeq )(i, model ) for i in inputs)

    # add a correction
    def plot_ts_pyeq2(site, model):

        import pyacs.lib.robustestimators
        import numpy as np

        diff = model.Ogts.__dict__[site].data[:,1:4] - model.Mgts.__dict__[site].data[:,1:4]

        DN, _tmp = pyacs.lib.robustestimators.Dikin( np.ones((diff.shape[0],1)),diff[:,0],np.ones(diff.shape[0]))
        DE, _tmp = pyacs.lib.robustestimators.Dikin( np.ones((diff.shape[0],1)),diff[:,1],np.ones(diff.shape[0]))
        DU, _tmp = pyacs.lib.robustestimators.Dikin( np.ones((diff.shape[0],1)),diff[:,2],np.ones(diff.shape[0]))

        model.Ogts.__dict__[site].data[:, 1:4] = model.Ogts.__dict__[site].data[:, 1:4] - np.array([DN,DE,DU]).flatten()

        _dev_nul = model.Ogts.__dict__[site].plot( \
            superimposed=[model.Mgts.__dict__[site]], \
            date_unit='cal', \
            save_dir_plots=model.odir + '/plots/ts2', \
            save=True, \
            show=False, \
            center=False, \
            verbose=model.verbose, \
            )
    for site in model.Ogts.lcode():
        plot_ts_pyeq2(site, model)

#    processed_list = Parallel(n_jobs=num_cores)(delayed(plot_ts_pyeq)(i, model) for i in inputs)
