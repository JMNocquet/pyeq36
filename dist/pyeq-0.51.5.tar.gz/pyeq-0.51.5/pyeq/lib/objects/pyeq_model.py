class pyeq_model:     
    def __init__ (self):
        pass

    @classmethod
    ###################################################################
    def load(cls, file_name=None, verbose=False):
    ###################################################################
        """
        load an existing pyeq model.

        param file_name: model file as pickle
        param verbose: verbose mode

        """

        import pickle
        import os
        from colors import red
        import sys

        try:
            print("-- Loading %s (%.2f Gb) " % ( file_name , os.path.getsize( file_name ) /1024 / 1024 / 1024 ) )
            with open( file_name, "rb") as f:
                model = pickle.load( f )
            f.close()
            print("-- model object loaded.")
        except:
            print( red("[PYEQ ERROR] Could not load: %s " % ( file_name ) ))
            sys.exit()

        return model