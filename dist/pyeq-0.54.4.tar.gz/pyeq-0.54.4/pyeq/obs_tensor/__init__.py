###############################################################################
# CUSTOM IMPORT
###############################################################################

# __custom_import__ = [          \
#                      'dk_from_obs_tensor',\
#                      'obs_tensor2sgts',\
#                      'reorder_obs_tensor_from_names',\
#                      'set_zero_at_first_obs',\
#                      'sgts2obs_tensor']
# 
# 
# 
# for mod in __custom_import__:
#     exec('from .' + mod + ' import *')
