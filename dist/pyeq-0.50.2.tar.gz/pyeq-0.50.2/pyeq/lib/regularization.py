"""
Handles regularization constraints
"""

###############################################################################
def add_Cminv_to_ATPA(ATPA,Cm_inv,w):
###############################################################################
    """
    Adds Cm^{-1} to ATPA
    
    ATPA: 2D numpy square array of shape (nstep x nfaults, nstep x nfaults)
    Cm_inv: Cm^{-1} the inverse of slip covariance matrix 2D numpy square array of shape (nfaults, nfaults)
    w : a scalar or 1D array of factors applied to Cm_inv
    """
    
    
    import numpy as np

    nstep = int( ATPA.shape[0] / Cm_inv.shape[0] )
    nfaults = Cm_inv.shape[0]

    if not isinstance(w,np.ndarray):
        w =  (np.zeros(nstep) + 1. ) * w


    for i in np.arange(nstep): 
    
        print(("-- adding spatial regularization constraints at step # %04d  over %04d time steps" %(i+1, nstep) ))
        
        ATPA[i*nfaults:(i+1)*nfaults,i*nfaults:(i+1)*nfaults] += Cm_inv * w[i]
        
    return(ATPA)

###############################################################################
def renorm_w_geometry(SGEOMETRY, Dm, Cm_type , dc):
###############################################################################
    """
    calculates a renormalization factor according to the discretization
    
    :param SGEOMETRY: rec array of pyea geometry
    :param Dm: Distance matrix as 2D numpy array
    :param Cm_type: 'exponential' or 'm_exponential'
    :param dc: correlation distance
    """

    import numpy as np
    
    # gets dc0 = minimum characteristic length for discretization
    dc0=np.sqrt(np.min(SGEOMETRY.rdis_area))
    
    # exponential case w= dc0**2 * n / np.sum(np.exp(-Dm/dc))
    if Cm_type=='exponential':
        w= dc0**2 * SGEOMETRY.rdis_area.shape[0]**2 / np.sum(np.exp(-Dm/dc))
    
    # Radiguet case w= dc**2 * n / np.sum(np.exp(-Dm/dc))
    if Cm_type=='m_exponential':
        w= dc**2 * SGEOMETRY.rdis_area.shape[0] / np.sum(np.exp(-Dm/dc))

    return(w)

