def plot_model( model , interpolation=False ):
    """
    plot models
    """
    
    ###################################################################
    # IMPORT
    ###################################################################

    import geopandas
    from glob import glob
    import matplotlib as mpl
    import matplotlib.pylab as plt
    from geopandas.plotting import plot_polygon_collection    
    import matplotlib.colors as colors
    from matplotlib.tri import Triangulation, TriAnalyzer, UniformTriRefiner    
    import numpy as np
    import multiprocessing
    from joblib import Parallel, delayed
    from tqdm import tqdm
    from os import mkdir, path

    ###################################################################
    # NUMBER OF CPU FOR PARALLEL JOBS
    ###################################################################
    num_cores = np.max( [ multiprocessing.cpu_count()-10 , 2 ] )


    ###################################################################
    # DEFINE THE UPPER BOUNDS VALUE FOR COLOR SCALE
    ###################################################################

    def get_max_scale( mx ):
        import numpy as np
        
        scale =  np.arange( 10**int(  np.log10( mx )  ) ,  10**(int(  np.log10( mx )  )+1)+ 10** int(  np.log10( mx )) , 10** int(  np.log10( mx )  ))
        
        return scale[np.where( scale > mx )][0] 


    ###################################################################
    # CUSTOM MAP
    ###################################################################
    # custom color map
    cmap = plt.cm.magma_r  # define the colormap
    # extract all colors from cmap
    cmaplist = [cmap(i) for i in range(cmap.N)]
    # force the first color entry to be grey
    cmaplist[0] = (1., 1., 1., 1. )
    # create the new map
    cmap = mpl.colors.LinearSegmentedColormap.from_list('my_cmap', cmaplist, cmap.N)

    ###################################################################
    # CASE INTERPOLATION
    ###################################################################

    if interpolation:

        if not path.exists(  model.odir +'/plots/i_model_cumulative' ):mkdir(  model.odir +'/plots/i_model_cumulative' )
        if not path.exists(  model.odir +'/plots/i_model_rate' ):mkdir(  model.odir +'/plots/i_model_rate' )
    
    ###################################################################
    # PLOT MODEL CUMULATIVE
    ###################################################################
    def plot_model_cumulative( shp , cmap , norm , title , mxslip , outdir ):
        slip = geopandas.read_file( shp )
        fig, ax = plt.subplots()
        ax.set_aspect('equal')
        plot_polygon_collection(ax, slip['geometry'],alpha=230)
        plot_polygon_collection(ax, slip['geometry'][slip.slip>0], slip['slip'][slip.slip>0],cmap=cmap, norm=norm )
        sm = plt.cm.ScalarMappable(cmap=cmap , norm=norm )
        sm.set_array([0., get_max_scale( mxslip * 1.1 ) ])
        plt.colorbar(sm)
        
        listarray=[]                                                                                                                                                                      
        for slip in slip.slip : 
            listarray.append([slip]) 
        z = np.array(listarray).flatten()
        
        title = ("%s - max : %.f mm" % (title , z.max() ))
        plt.title( title , fontsize=8 )
        plot_name = ("%s/%s_cumulative.pdf" % ( outdir , shp.split('/')[-1][:4] ) )
        plt.savefig( plot_name )
        plt.close( 'all' )
    ###################################################################

    ###################################################################
    # PLOT MODEL CUMULATIVE CONTOUR
    ###################################################################
    def plot_model_cumulative_contour( shp , cmap , norm , title , mxslip , outdir ):
        slip = geopandas.read_file( shp )
        fig, ax = plt.subplots()
        ax.set_aspect('equal')
        plot_polygon_collection(ax, slip['geometry'],alpha=0.5)

        sm = plt.cm.ScalarMappable(cmap=cmap , norm=norm )
        sm.set_array([0., get_max_scale( mxslip * 1.1 ) ])
        plt.colorbar(sm)
        
        # test contour
        listarray=[]                                                                                                                                                                      
        for pp in slip.centroid : 
            listarray.append([pp.x, pp.y]) 
        coor = np.array(listarray) 

        listarray=[]                                                                                                                                                                      
        for slip in slip.slip : 
            listarray.append([slip]) 
        z = np.array(listarray).flatten()

        # meshing with Delaunay triangulation
        tri = Triangulation( coor[:,0], coor[:,1])
        ntri = tri.triangles.shape[0]
        # masking badly shaped triangles at the border of the triangular mesh.
        min_circle_ratio = .1  # Minimum circle ratio - border triangles with circle
                                # ratio below this will be masked if they touch a
                                # border. Suggested value 0.01; use -1 to keep
                                # all triangles.
        
        mask = TriAnalyzer(tri).get_flat_tri_mask(min_circle_ratio)
        tri.set_mask(mask)
        
        # refining the data
        subdiv=3
        levels = np.linspace(0., mxslip, 10 )        
        refiner = UniformTriRefiner(tri)
       
        tri_refi, z_test_refi = refiner.refine_field( z , subdiv=subdiv)

        plt.tricontourf(tri_refi, z_test_refi, levels=levels, cmap=cmap , norm=norm )
        
        title = ("%s - max : %.f mm" % (title , z.max() ))
        plt.title( title , fontsize=8 )
        plot_name = ("%s/%s_cumulative_contour.pdf" % ( outdir , shp.split('/')[-1][:4] ) )
        plt.savefig( plot_name )
        plt.close( 'all' )
    ###################################################################

    ###################################################################
    # VARIABLES FOR LOOP OF CUMULATIVE MODELS
    ###################################################################
        
    mxslip = model.cumulative_slip_max * 1.1
    bounds = np.linspace(0, get_max_scale( mxslip ), 21)
    norm = mpl.colors.BoundaryNorm(bounds, cmap.N)

    # title
    # load cstf
    H_title = {}
    H_shp   = {}
    H_ishp   = {}
    cstf = np.genfromtxt( model.odir+'/stf/cstf.dat' , dtype=str)
    for i in np.arange( cstf.shape[0] ):
        H_title[i] = ("%s -- time step %04d \n\n day %04d - %s %s - Mo=%s N.m" % ( model.name , i, int(float((cstf[i,0]))), cstf[i,2] , cstf[i,3], cstf[i,1] ))
        H_shp[i] = ("%s/shapefile/slip_cumulative/%04d_cumulative_slip.shp" % ( model.odir , i ) )
        H_ishp[i] = ("%s/shapefile/i_slip_cumulative/%04d_cumulative_slip.shp" % ( model.odir , i ) )
    
    if interpolation:
        outdir = model.odir+'/plots/i_model_cumulative'
        print('-- making plot for interpolated cumulative slip in ' , outdir )
        processed_list = Parallel(n_jobs=num_cores)(delayed( plot_model_cumulative )\
                                                    ( H_ishp[i], cmap , norm , H_title[i] , mxslip , outdir ) for i in tqdm(np.arange( cstf.shape[0] )) )

    if not interpolation:
        outdir = model.odir+'/plots/model_cumulative'
        print('-- making plot for cumulative slip in ' , outdir )
        processed_list = Parallel(n_jobs=num_cores)(delayed( plot_model_cumulative )\
                                                    ( H_shp[i], cmap , norm , H_title[i] , mxslip , outdir ) for i in tqdm(np.arange( cstf.shape[0] )) )

        outdir = model.odir+'/plots/model_cumulative_contour'
        if not path.exists(  outdir ):mkdir(  outdir )
        print('-- making contour plot for cumulative slip in ' , outdir )
        processed_list = Parallel(n_jobs=num_cores)(delayed( plot_model_cumulative_contour )\
                                                    ( H_shp[i], cmap , norm , H_title[i] , mxslip , outdir ) for i in tqdm(np.arange( cstf.shape[0] )) )

    ###################################################################
    # PLOT MODEL RATE
    ###################################################################

    def plot_model_rate_contour( shp , cmap , norm , title , mxslip , outdir ):
        
        from matplotlib import ticker
        from matplotlib.ticker import LogFormatter        
        
        slip = geopandas.read_file( shp )
        fig, ax = plt.subplots()
        ax.set_aspect('equal')
        plot_polygon_collection(ax, slip['geometry'],alpha=0.5)

        sm = plt.cm.ScalarMappable(cmap=cmap , norm=norm )
        sm.set_array([0., get_max_scale( mxslip * 1.1 ) ])
        #plt.colorbar(sm)
        
        # test contour
        listarray=[]                                                                                                                                                                      
        for pp in slip.centroid : 
            listarray.append([pp.x, pp.y]) 
        coor = np.array(listarray) 

        listarray=[]                                                                                                                                                                      
        for slip in slip.slip : 
            listarray.append([slip]) 
        z = np.array(listarray).flatten()
        # modifies z
        z[np.where(z==0)] = 0.01
        #z = np.log10(z)
        # meshing with Delaunay triangulation
        tri = Triangulation( coor[:,0], coor[:,1])
        ntri = tri.triangles.shape[0]
        # masking badly shaped triangles at the border of the triangular mesh.
        min_circle_ratio = .1  # Minimum circle ratio - border triangles with circle
                                # ratio below this will be masked if they touch a
                                # border. Suggested value 0.01; use -1 to keep
                                # all triangles.
        
        mask = TriAnalyzer(tri).get_flat_tri_mask(min_circle_ratio)
        tri.set_mask(mask)
        
        # refining the data
        subdiv=2
        #levels = np.linspace( 0.1,  mxslip , 10 )        
        refiner = UniformTriRefiner(tri)
       
        tri_refi, z_test_refi = refiner.refine_field( z , subdiv=subdiv)

#        plt.tricontourf(tri_refi, z_test_refi, levels=levels, cmap=cmap , norm=norm )
        z_test_refi[np.where(z_test_refi<0)] = 0.1
              
        # Alternatively, you can manually set the levels
        # and the norm:
        lev_exp = np.arange(np.floor(np.log10(z.min())-1), np.ceil(np.log10(mxslip)+1) , 0.1 )
        levs = np.power(10, lev_exp)
        # cs = ax.contourf(X, Y, z, levs, norm=colors.LogNorm())
        #levels = np.log10np.linspace(mxslip*0.001, mxslip , num=500)
        cs = plt.tricontourf(tri_refi, z_test_refi, locator=ticker.LogLocator() , levels=levs, norm=colors.LogNorm() , cmap='jet' )
        cbar = plt.colorbar( cs , ticks=[0.01,0.1,1,10,100,1000] )
        cbar.set_label('slip rate mm/day', rotation=270)
        
        title = ("%s - max : %.2f mm/day" % (title , z.max() ))
        plt.title( title , fontsize=8 )
        plot_name = ("%s/%s_cumulative_contour.pdf" % ( outdir , shp.split('/')[-1][:4] ) )
        plt.savefig( plot_name )
        plt.close( 'all' )
    ###################################################################

    ###################################################################
    # VARIABLES FOR LOOP OF RATE MODELS
    ###################################################################
        
    mxslip = model.rate_slip_max * 1.1
    bounds = np.linspace(0, get_max_scale( mxslip ), 21)
    norm = mpl.colors.BoundaryNorm(bounds, cmap.N)

    # title
    # load cstf
    H_title = {}
    H_shp   = {}
    H_ishp   = {}
    stf = np.genfromtxt( model.odir+'/stf/stf.dat' , dtype=str)
    for i in np.arange( stf.shape[0] ):
        H_title[i] = ("%s -- time step %04d \n\n day %04d - %s %s - Mo=%s N.m" % ( model.name , i, int(float((stf[i,0]))), stf[i,2] , stf[i,3], stf[i,1] ))
        H_shp[i] = ("%s/shapefile/slip_rate/%04d_slip_rate.shp" % ( model.odir , i ) )
        H_ishp[i] = ("%s/shapefile/i_slip_rate/%04d_slip_rate.shp" % ( model.odir , i ) )
    
    if interpolation:
        outdir = model.odir+'/plots/i_model_rate'
        print('-- making plot for interpolated rate slip in ' , outdir )
        processed_list = Parallel(n_jobs=num_cores)(delayed( plot_model_cumulative )\
                                                    ( H_ishp[i], cmap , norm , H_title[i] , mxslip , outdir ) for i in tqdm(np.arange( stf.shape[0] )) )

    if not interpolation:
        print('-- making plot for rate slip in ' , outdir )
        outdir = model.odir+'/plots/model_rate'
        processed_list = Parallel(n_jobs=num_cores)(delayed( plot_model_cumulative )\
                                                    ( H_shp[i], cmap , norm , H_title[i] , mxslip , outdir ) for i in tqdm(np.arange( stf.shape[0] )) )

        bounds = np.linspace(np.log10(0.1), np.log10(get_max_scale( mxslip )), 1001)
        norm = mpl.colors.BoundaryNorm(bounds, cmap.N)
        outdir = model.odir+'/plots/model_rate_contour'
        if not path.exists(  outdir ):mkdir(  outdir )
        print('-- making contour plot for rate slip in ' , outdir )
        processed_list = Parallel(n_jobs=num_cores)(delayed( plot_model_rate_contour )\
                                                    ( H_shp[i], cmap , norm , H_title[i] , mxslip , outdir ) for i in tqdm(np.arange( stf.shape[0] )) )


