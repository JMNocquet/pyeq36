class pyeq_model:     
    def __init__ (self):
        pass

