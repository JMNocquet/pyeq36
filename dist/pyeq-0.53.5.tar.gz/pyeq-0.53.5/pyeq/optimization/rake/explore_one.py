
def explore_one( model ):

    pass