"""
Routines to build the linear system
"""

def build2(T_OBS, \
           np_obs_date_s, \
           np_model_date_s, \
           NAME_OBS, \
           GREEN, \
           UP, \
           RAKE=False, \
           s_up=1.0, \
           rounding='day', \
           lexclude_gps=[], \
           verbose=True,\
           debug=False):
    """
    
    :param T_OBS: Observation tensor
    :param np_model_dates: numpy 1D array of model dates
    :param NAME_OBS: numpy 1D array of site name
    :param GREEN: Green tensor as a 4D numpy array
    :param UP: boolean, True means up component will be included
    :param RAKE: boolean, True means variable rake model
    :param s_up: rescaling factor for the up component
    :param rounding: 'day','hour','second'. all dates will be rounded to the nearest chosen day, hour or second. default is 'day'
    :param verbose: verbose mode
    
    :return ATPA, ATPB: LHS matrix and RHS vector ready for inversion algorithm
    """

    print("-- BUILDING THE NORMAL SYSTEM USING PYEQ.LIB.BUILD2 --")

    #print('GREEN in build2 ' , GREEN)
    ### TO BE DONE
    ### renormalize Gk by Cd-1/2
    ### RAKE handling - check whether GREEN has been modified before build2 call
    ### ADD ORIGIN TIME CONSTANT AS ESTIMATED PARAMETER
    ### PARAMETER TRANSLATION FOR CONJUGATE RAKE AND/OR ORIGIN TIME CONSTANT
    
    n_constant = 0
    

    ###########################################################################
    # import
    ###########################################################################
    
    import numpy as np
    import pyeq.lib.elastic_tensor.shrink
    import pyeq.lib.obs_tensor
    import pyacs.lib.glinalg
    import pyacs.lib.astrotime as at
    import resource

    ###########################################################################
    # COMPONENTS & RAKE
    ###########################################################################
    
    # components
    if UP:
        np_component = np.array( [0,1,2] )
    else:
        np_component = np.array( [0,1] )
    
    if debug:
        print("-- np_component:" , np_component )
    
    # rake
    if RAKE:
        np_rake = np.array( [0,1] )
    else:
        np_rake = np.array( [0] )

    nrake = np_rake.shape[0] 
    
    # debug
    if debug:
        print("-- np_rake:" , np_rake )
        
    ###########################################################################
    # OBSERVATION TENSOR
    ###########################################################################

    # let's try to make a data tensor
    # D(i,j,k) would be the displacement divided by the uncertainty
    # observation time index i
    # for site j
    # for component k
    # no data would be Nan
    
    # for now (08/10/2019), the observation tensor is np_dates_index, code, [NEU,sNEU]
    
#    import pyeq.lib.obs_tensor.sgts2obs_tensor
    import pyeq.lib.obs_tensor.dk_from_obs_tensor
#    import pyeq.lib.obs_tensor.reorder_obs_tensor_from_names    
#    import pyeq.lib.obs_tensor.set_zero_at_first_obs
# 
#         
#     if verbose:
#         print("-- converting sgts time series to observation tensor using pyeq.lib.obs_tensor.sgts2tensor")
#         
#     T_OBS_RAW , np_names_t_obs, np_obs_date_s = pyeq.lib.obs_tensor.sgts2obs_tensor.sgts2tensor( sgts, rounding=rounding , verbose=verbose )
# 
#     if verbose:
#         print("-- raw_observation_tensor shape: " , T_OBS_RAW.shape)
#     
#     ###########################################################################
#     # MAKING OBSERVATION AND GREEN TENSOR CONSISTENT
#     ###########################################################################
#     
#     print("-- Reordering and extracting Observation and Green tensors")
# 
#     # find common gps sites
#     np_gps_site , np_common_index_obs_tensor, np_common_index_elastic_tensor = np.intersect1d(np_names_t_obs, NAME_OBS, assume_unique=True, return_indices=True)
# 
#     if verbose:
#         print('-- List of GPS site both in the Green and Observation Tensor')
#         print(np_gps_site)
# 
#     # remove excluded sites
#     np_gps_exclude, np_index_exclude, _ = np.intersect1d( np_gps_site, np.array( lexclude_gps ), assume_unique=True, return_indices=True )
# 
#     if verbose:
#         print('-- User defined GPS site to be excluded from inversion')
#         print(np_gps_exclude)
# 
#     
#     np_gps_site = np.delete( np_gps_site, np_index_exclude )
#     np_common_index_obs_tensor = np.delete( np_common_index_obs_tensor, np_index_exclude )
#     np_common_index_elastic_tensor = np.delete( np_common_index_elastic_tensor, np_index_exclude )
#     
#     # making extraction    
#     T_OBS_RAW = T_OBS_RAW[ : , np_common_index_obs_tensor, :]
#     GREEN     = GREEN[np_common_index_elastic_tensor]
#     
#     print("-- Observation tensor new shape: " , T_OBS_RAW.shape )
#     print("-- Elastic tensor new shape: " , GREEN.shape )
#     
#     ###########################################################################
#     # rescale sigma up
#     ###########################################################################
# 
#     print("-- rescaling up sigma by: %.2lf" % s_up )
#     
#     T_OBS_RAW[:,:,5] = T_OBS_RAW[:,:,5] * s_up 
# 
#     ###########################################################################
#     # MAKING OBSERVATION AND MODEL DATE CONSISTENT
#     ###########################################################################
#     
#     # we will need np_obs_dates including the observation dates in seconds since np_model_dates_s[0]
#     
#     print("-- Checking that model and observation dates are consistent")
#     print("-- number of model dates requested by user: %d" % (np_model_dates.shape[0] ) )
#     print("-- start     model date  requested by user: %.6lf" % (np_model_dates[0] ) )
#     print("-- end       model date  requested by user: %.6lf" % (np_model_dates[-1] ) )
#     
#     import pyacs.lib.astrotime as at 
#     np_model_date_s = at.decyear2seconds( np_model_dates, rounding=rounding )
# 
#     # check compatibility of obs and model dates
#     
#     print("-- Checking model/obs date consistency")
#     if np_model_date_s[0] < np_obs_date_s[0]:
#         print("!!!WARNING: requested model date starts before data. Changing model start date to the first available observation date.")
#         np_model_date_s = np.append( np_model_date_s , np_obs_date_s[0] )
#     
#     if np_model_date_s[-1] > np_obs_date_s[-1]:
#         print("!!!WARNING: requested model date (%d) ends after data end (%d)" % ( np_model_date_s[-1] , np_obs_date_s[-1] ))
#         print("!!! Changing model end date to the last available observation date.")
#         np_model_date_s = np.append( np_model_date_s , np_obs_date_s[-1] )
# 
#     np_model_date_s = np.unique( np.sort( np_model_date_s ))
#     
#     lindex = np.where( (np_model_date_s>=np_obs_date_s[0]) & (np_model_date_s<=np_obs_date_s[-1]) )
#     np_model_date_s = np_model_date_s[lindex]
#     
#     # extract the model period for the time series
#     
#     print("-- Extracting time series for the user defined model period"  )
#     lindex = np.where( (np_obs_date_s >= np_model_date_s[0]) &  (np_obs_date_s <= np_model_date_s[-1]) )
#     T_OBS = T_OBS_RAW[lindex]
#     np_obs_date_s = np_obs_date_s[ lindex ]
#     print("-- Extracted observation tensor for modeling period: " , T_OBS.shape )
#     print("-- Number of observation dates: %d" % (np_obs_date_s.shape[0]) )
#     print("-- number of observation dates used for modeling: %d " % T_OBS.shape[0])
#     
#     #print("-- removing observation epochs with no data")
#     
# 
#     # remove GPS site with no data
#     print("-- removing GPS sites with no data for the model period")
#     
#     np_index_gps_no_data = np.array([] , dtype=int )
#     
#     for i in np.arange( np_gps_site.shape[0] ):
#         code = np_gps_site[i]
#         if  np.isnan(T_OBS[:,i][:,0]).all():
#             np_index_gps_no_data = np.append( np_index_gps_no_data , i ) 
#          
#     print("-- GPS site with no data within the model period")
#     print(np_gps_site[ np_index_gps_no_data ])
# 
#     np_gps_site = np.delete( np_gps_site, np_index_gps_no_data )
#     np_common_index_obs_tensor = np.delete( np.arange( T_OBS.shape[1] ), np_index_gps_no_data )
#     np_common_index_elastic_tensor = np.delete( np.arange( GREEN.shape[0] ), np_index_gps_no_data )
#     
#     # making extraction    
#     T_OBS = T_OBS[ : , np_common_index_obs_tensor, :]
#     GREEN     = GREEN[np_common_index_elastic_tensor]
#     
#     print("-- Observation tensor new shape: " , T_OBS.shape )
#     print("-- Elastic tensor new shape: " , GREEN.shape )
#     
#     print("-- final list of GPS sites used in inversion: %d" % (np_gps_site.shape[0]) )
#     print(np_gps_site)
# 
#     #### data so far is not yet set to zeros for the first obs, correct that
#     print("-- Setting the first observation as the reference using pyeq.lib.obs_tensor.set_zero_at_first_obs")
#     T_OBS = pyeq.lib.obs_tensor.set_zero_at_first_obs.set_zero_at_first_obs( T_OBS , verbose=verbose )
#     
#     # switch T_OBS from NE to EN for compatibility with the GREEN's tensor
#     
#     T_OBS[:,:,[0,1]] = T_OBS[:,:,[1,0]]
    
    ###########################################################################
    # AUXILIARY INDEX
    ###########################################################################
    
    print('-- list of observation dates')
    for i in np.arange( T_OBS.shape[0] ):
        print("%s" % ( at.seconds2datetime( np_obs_date_s[i] ).isoformat(' ')   ) )
    
    print("-- Building H_i_k  : dictionary providing the list of indexes k for observation time for each model time step i")
    # H_i_k  : dictionary providing the list of indexes k for observation time for each model time step i
    H_i_k = {}

    
    for model_time_step in np.arange( np_model_date_s.shape[0]-2 , -1, step = -1 ):
        sdate_s = np_model_date_s[ model_time_step ]
        edate_s = np_model_date_s[ model_time_step + 1 ]
        print("--- model_time_step: %04d %s -> %s " % ( model_time_step, at.seconds2datetime(sdate_s).isoformat(' '), at.seconds2datetime(edate_s).isoformat(' ') ) )
        H_i_k[ model_time_step ] = []
        
        for k in np.arange(np_obs_date_s.shape[0]):
            if ( ( np_obs_date_s[k] > sdate_s ) and ( np_obs_date_s[k] <= edate_s ) ):
                #print( np_obs_date_s[k] )
                H_i_k[ model_time_step ].append( k )
                 
        H_i_k[ model_time_step ] = sorted( H_i_k[ model_time_step ] )
        
    if verbose:
        print("--- list of observation index per model time step")
        for key, value in H_i_k.items():
            
            print("--- model time step %d: %s " % (key,value) )
            

    # H_k_obs: dictionary providing the list of GNSS site indexes available at observation time t_k

    print("-- Building H_k_obs: dictionary providing the list of GNSS site indexes available at observation time t_k")
    
    H_k_obs = {}
    for k in np.arange(np_obs_date_s.shape[0]):
        H_k_obs[ k ] = np.where( np.isfinite(T_OBS[ k,:,0 ]))

    if debug:
        print('H_k_obs')
        for key, value in H_k_obs.items():
            print(key,value)

        for klkl in np.arange( NAME_OBS.shape[0] ):
            print("%04d %s" % ( klkl, NAME_OBS[ klkl ] ))

    ## stupid?! H_k_tk : dictionary providing the observation date tk at the observation index k


    ###########################################################################
    # ATPA ATBP and various variables initialization
    ###########################################################################

    n_model_time_step = np_model_date_s.size - 1
    nfaults = GREEN.shape[1]
    
    
    print("-- Initializing ATPA & ATPB")
    
    # ATPA
    
    memory_usage = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024 / 1024
    print("-- memory usage before ATPA initialization in Gb Linux/Mac OS X : %.1lf / %.1lf" %  (memory_usage,memory_usage/1024) )

    n_atpa = nfaults * nrake * n_model_time_step + n_constant
    ATPA = np.zeros( (n_atpa,n_atpa) )

    memory_usage = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024 / 1024
    print("-- memory usage after ATPA initialization in Gb Linux/Mac OS X : %.1lf / %.1lf" %  (memory_usage,memory_usage/1024) )
    
    # ATPB
    
    ATPB = np.zeros( (n_atpa,1) )

    memory_usage = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024 / 1024
    print("-- memory usage after ATPB initialization in Gb Linux/Mac OS X : %.1lf / %.1lf" %  (memory_usage,memory_usage/1024) )

    # COLUMN OF ATPA CORRESPONDING TO A TIME STEP

    # number of columns for C
    ncc = nfaults * nrake
    print('-- nrake' , nrake)
    print('-- nfaults' , nfaults)
    print("-- Initializing the individual model time step matrices")
    C = np.zeros( ( ncc * n_model_time_step , ncc ) )

    # GAMMA MODEL STEP DURATION VECTOR
    
    print("-- Initializing the vector of time duration")
    GAMMA = np.diff( np_model_date_s , 1 )
    
    ###########################################################################
    # loop on model time steps
    ###########################################################################

    # RHS sub-vector
    Bi = np.zeros( ( nfaults*nrake , 1 ) )

    
    # loop is made reverse in time
    for model_time_step in np.arange( n_model_time_step-1, -1, -1 ):
#    for model_time_step in np.arange( np_model_date_s.shape[0]-2 , -1, step = -1 ):
  
        if verbose:
            print("-- Building equations for model time step: %04d" % model_time_step )
        
        # Get the list of the k-index of observation time within the current model time step
        
        lk = H_i_k[ model_time_step ]
        
        
        #######################################################################
        # loop on k observation time within the current model time step
        #######################################################################
        for k in lk:
            
            # get tk time for observation k
            
            tk = np_obs_date_s[ k ]
            print("-- model time step: %04d observation time step: %04d %s" % (model_time_step , k, at.seconds2datetime(tk).isoformat(' ') ) )
            
            # get Gkt and Gk2
            if debug:
                print("-- model time step: %04d observation time step: %04d Gkt from pyeq.lib.elastic_tensor.shrink"  % (model_time_step , k ) )
            
            # extract Gkt as a 2D matrix for available sites with the chosen components at date tk
            Gkt = pyeq.lib.elastic_tensor.shrink.shrink( GREEN, lfaults=None, lobs=H_k_obs[k], lcomponent=np_component, lrake=np_rake).T

            print('GREEN in build 2')
            print(Gkt.T)

            # Get dk, observation vector at date tk for available sites with the chosen components
            if debug:
                print("-- model time step: %04d observation time step: %04d get normalized observation using pyeq.lib.obs_tensor.dk_from_obs_tensor"  % (model_time_step , k ) )
            
            Dk = T_OBS[k][ H_k_obs[k] ][:,np_component].T.flatten()

            # normalize the observation vector
            Sdk = T_OBS[k][ H_k_obs[k] ][:,np_component +3 ].T.flatten()
            # !!!! DO NOT FORGET TO REMOVE AFTER TEST
            Sdk = Sdk * 0.0 + 1.
            Dk  = Dk / Sdk

            # normalize the Green matrix
            Gkt = (Gkt / Sdk ) 
            Gk2 = np.dot( Gkt , Gkt.T )
            
            # handle the Gamma functions
            # get GAMMA, change for the current time step, remove time steps after the current one to ensure size is compatible with C
            # we choose as a unit for parameters delta_m, slip rate expressed in mm/day
            if debug:
                print("-- model time step: %04d observation time step: %04d gamma_k: vector of duration"  % (model_time_step , k ) )

            gamma_k = np.copy( GAMMA )
            gamma_k[ model_time_step ] = ( tk - np_model_date_s[ model_time_step ] )
            gamma_k = gamma_k / 86400.
            
            print('gamma_k',gamma_k)

            # Update C (See "Algorithm to build the observation normal system in paper")
            if debug:
                print("-- model time step: %04d observation time step: %04d Individual column matrix for ATPA"  % (model_time_step , k ) )
            C = C + gamma_k[ model_time_step ] * pyacs.lib.glinalg.odot( gamma_k[:model_time_step+1] , pyacs.lib.glinalg.repeat_matrix_in_col(Gk2 , model_time_step+1 ) )
            
            print('C')
            print(C)
            
            # Update Bk
            if debug:
                print("-- model time step: %04d observation time step: %04d Individual vector for ATPB"  % (model_time_step , k ) )
            Bi = Bi + gamma_k[ model_time_step ] * np.dot( Gkt , Dk.reshape(-1,1) )
            
        #######################################################################
        # end loop on k
        #######################################################################

        # C is ready to be inserted into ATPA
        
        # inserting C as a column
        if debug:
            print("-- model time step: %04d Inserting the normal observation column in ATPA"  % (model_time_step ) )
        ATPA[ :C.shape[0] , model_time_step*ncc:(model_time_step+1)*ncc ] = C


        # inserting C.T as a row
        if debug:
            print("-- model time step: %04d Inserting the normal observation row in ATPA"  % (model_time_step ) )
        ATPA[ model_time_step*ncc:(model_time_step+1)*ncc , :C.shape[0] ] = C.T

        # Updating ATPB
        if debug:
            print("-- model time step: %04d Updating ATPB"  % (model_time_step ) )
        
        ATPB[ model_time_step*ncc:(model_time_step+1)*ncc ] = Bi 

        #######################################################################
        # end of the current model time step
        #######################################################################
        
        # Remove the last rows of C corresponding to the current time step
        if debug:
            print("-- model time step: %04d Resizing individual column matrix for next model time step"  % (model_time_step ) )
        
        C = C[:-ncc,:]
        
    return ATPA , ATPB



